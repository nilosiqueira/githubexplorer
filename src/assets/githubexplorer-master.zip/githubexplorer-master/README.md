<h1 align="center">GithubExplorer</h1>
<h3 align="center">GoStack - An application to find information from GitHub repositories 🌐</h3>

# How to use

To start your React.js website:

```
# Clone this repository
$ https://github.com/VictorMenegazzo/githubexplorer.git

# Install dependencies
$ yarn install

# Start the project
$ yarn start
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

# License
This project is under the MIT license.

---
 Made with 💙 by Victor Menegazzo 👋
